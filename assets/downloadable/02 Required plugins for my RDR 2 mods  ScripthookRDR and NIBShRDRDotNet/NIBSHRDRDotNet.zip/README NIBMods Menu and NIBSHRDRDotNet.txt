NIBSHRDRDotNet v1.0 by JulioNIB - Based on Community Script Hook RDR2 .NET by Salty, Crosire

Installation: Extract all files and folders from the zip to game main folder.


############## About NIBMods Menu ############## 

This is the script that i use to handle all my mods menus, it's based on my GTA 5 version and its required to properly use my mods.

Important: Never put plugin files like NIBSHRDRDotNet.dll, ScripthookRDRDotNet.dll, etc. into Scripts folder, only scripts and 
their files should go there, otherwise mods should not work as expected.

Hotkeys:

Ctrl + N - Show mods menu
Up/Down/Left/Right - Navigate
Enter - Select item
Backspace - Previous menu/Close menu


############## Required windows packages ############## 

.NET Framework 4.8
https://dotnet.microsoft.com/download/dotnet-framework/net48

Visual C++ Redistributable for Visual Studio 2019 x64
https://support.microsoft.com/en-us/help/2977003/the-latest-supported-visual-c-downloads


############## Required plugins for my RDR2 mods ############## 

-ScripthookRDR2 & ASI Loader:
http://www.dev-c.com/rdr2/scripthookrdr2/

-NIBSHRDRDotNet (My custom version of ScripthookRDRDotNet)
https://www.patreon.com/posts/rdr2-nibshdotnet-35902012

-OpenIV and OpenIV.asi may be needed too:
http://openiv.com/


############## Social media ############## 

Help me grow, share my links on your videos :)

https://www.youtube.com/user/GTAScripting
https://www.patreon.com/JulioNIB
https://www.facebook.com/GtaIVScripting
https://twitter.com/julionib