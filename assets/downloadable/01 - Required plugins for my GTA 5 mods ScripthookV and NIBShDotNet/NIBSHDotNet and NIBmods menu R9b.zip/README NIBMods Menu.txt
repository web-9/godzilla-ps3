About NIBMods Menu


General JulioNIB's mods setup guide:
https://gtaxscripting.blogspot.com/2020/09/gta-5-julionib-mods-setup-guide-oiv.html


This is the script that i use to handle all my mods menus, so, its required to properly use my mods. each mod goes with this script
but sometimes i make important changes and don't have time to replace all uploads with the update, this is why we have this
separated download only for the menu :)

-Install the file "Setup package.oiv" using OpenIV (menu Tools, submenu Package Installer)

Important: Never put plugin files like NIBSHDotNet.dll, ScripthookVDotNet.dll, etc. into gta Scripts folder, only scripts and 
their files should go there, otherwise mods should not work as expected.

Hotkeys:

Ctrl + N - Show mods menu
Up/Down/Left/Right (also numpads 2, 4, 6 and 8) - Navigate
Enter/Numpad5 - Select item
Numpad0/Backspace - Previous menu/Close menu

In controller:

Hold DPad Left and press X to show the NIBMods menu
Up/Down/Left/Right - Navigate
A (Sprint) - Select item
B - Previous menu/Close menu

Case you have issues making the menu appear when you press Ctrl + N check the troubleshooting:
http://gtaxscripting.blogspot.com.br/2016/05/ScripthookVDotNet-Troubleshooting.html



############## Required plugins for my GTA V mods ############## 

-ScripthookV & ASI Loader:
http://www.dev-c.com/gtav/scripthookv/

-NIBSHDotNet (My custom version of ScripthookVDotNet v2.10.9):
https://www.patreon.com/posts/nibmods-menu-22783974

-OpenIV and OpenIV.asi may be needed too (to edit RPF files, add peds, etc.):
http://openiv.com/


############## Tutorials and guides ############## 

General Help:                         https://gtaxscripting.blogspot.com/2019/05/gta-5-modding-help.html
.NET scripts basic setup:             https://www.youtube.com/watch?v=l88lGn96E7U
.NET scripts .oiv files setup:        http://gtaxscripting.blogspot.com.br/2016/07/tut-installing-oiv-packages-in-gta-v.html
Addon Peds plugin setup guide:        https://www.youtube.com/watch?v=ILruXAv_JJg
Add peds guide:                       https://www.youtube.com/watch?v=Lkws32GUd7I
Add peds game crash/limit FIX:        https://www.youtube.com/watch?v=TmBLlb51KMM
Replace peds guide:                   https://www.youtube.com/watch?v=75Igq9J6jbw


############## Social media ############## 

Help me grow, share my links on your videos :)

https://www.youtube.com/user/GTAScripting
https://www.patreon.com/JulioNIB
https://www.facebook.com/GtaIVScripting
https://twitter.com/julionib